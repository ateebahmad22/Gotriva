import { DashboardLayout } from "@/components/dashboard-layout"
import { MyTripsView } from "@/components/my-trips-view"

export default function MyTripsPage() {
  return (
    <DashboardLayout>
      <MyTripsView />
    </DashboardLayout>
  )
}
