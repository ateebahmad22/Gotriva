import { DashboardLayout } from "@/components/dashboard-layout"
import { CreateTripForm } from "@/components/create-trip-form"

export default function CreateTripPage() {
  return (
    <DashboardLayout>
      <div className="max-w-2xl space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-foreground">Create a Trip</h1>
          <p className="text-muted-foreground">Share your adventure and find travel companions to join you</p>
        </div>

        <CreateTripForm />
      </div>
    </DashboardLayout>
  )
}
