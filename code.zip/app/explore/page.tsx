"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"

interface Trip {
  id: string
  title: string
  destination: string
  start_date: string
  end_date: string
  budget_min: number
  budget_max: number
  difficulty_level: string
  thumbnail_url?: string
  current_participants: number
  max_participants: number
  organizer: {
    full_name: string
    avatar_url?: string
    trust_score: number
  }
}

export default function ExplorePage() {
  const [trips, setTrips] = useState<Trip[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchTrips = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) {
          router.push("/login")
          return
        }

        const response = await fetch("/api/trips")
        const data = await response.json()
        setTrips(data || [])
      } catch (error) {
        console.error("Failed to fetch trips:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchTrips()
  }, [supabase, router])

  if (isLoading) {
    return <div className="flex items-center justify-center h-screen">Loading trips...</div>
  }

  return (
    <DashboardLayout>
      <div className="p-6">
        <h1 className="text-3xl font-bold mb-6">Explore Trips</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trips.map((trip) => (
            <div
              key={trip.id}
              className="border rounded-lg overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => router.push(`/trip/${trip.id}`)}
            >
              <div className="bg-gradient-to-r from-teal-400 to-blue-500 h-32"></div>
              <div className="p-4">
                <h3 className="font-bold text-lg">{trip.title}</h3>
                <p className="text-muted-foreground text-sm">{trip.destination}</p>
                <div className="mt-4 flex justify-between text-sm">
                  <span className="text-primary font-semibold">
                    ${trip.budget_min}-${trip.budget_max}
                  </span>
                  <span className="text-muted-foreground">
                    {trip.current_participants}/{trip.max_participants}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  )
}
