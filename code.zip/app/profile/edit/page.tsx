import { DashboardLayout } from "@/components/dashboard-layout"
import { EditProfileForm } from "@/components/edit-profile-form"

export default function EditProfilePage() {
  return (
    <DashboardLayout>
      <div className="max-w-2xl space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-foreground">Edit Profile</h1>
          <p className="text-muted-foreground">Update your profile information and settings</p>
        </div>
        <EditProfileForm />
      </div>
    </DashboardLayout>
  )
}
