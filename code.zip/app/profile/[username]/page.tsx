import { DashboardLayout } from "@/components/dashboard-layout"
import { UserProfileView } from "@/components/user-profile-view"

export default function ProfilePage({ params }: { params: { username: string } }) {
  return (
    <DashboardLayout>
      <UserProfileView username={params.username} />
    </DashboardLayout>
  )
}
