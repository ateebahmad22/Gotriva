import { DashboardLayout } from "@/components/dashboard-layout"
import { MessageConversation } from "@/components/message-conversation"

export default function ConversationPage({ params }: { params: { username: string } }) {
  return (
    <DashboardLayout>
      <MessageConversation username={params.username} />
    </DashboardLayout>
  )
}
