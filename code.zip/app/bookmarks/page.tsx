"use client"

import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, MapPin, Calendar, Users } from "lucide-react"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"

interface BookmarkedTrip {
  id: string
  trip_id: number
  trips: {
    id: number
    title: string
    destination: string
    image: string
    dates: string
    travelers: number
    maxTravelers: number
    tags: string[]
    creator: string
    trustScore: number
    price: string
  }
}

export default function BookmarksPage() {
  const [bookmarkedTrips, setBookmarkedTrips] = useState<BookmarkedTrip[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")
  const supabase = createClient()

  useEffect(() => {
    const fetchBookmarks = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (!user) {
          window.location.href = "/login"
          return
        }

        const { data, error: fetchError } = await supabase
          .from("saved_trips")
          .select(
            `
            id,
            trip_id,
            trips (
              id,
              title,
              destination,
              image,
              dates,
              travelers,
              max_travelers,
              tags,
              creator,
              trust_score,
              price
            )
          `,
          )
          .eq("user_id", user.id)

        if (fetchError) throw fetchError
        setBookmarkedTrips(data || [])
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load bookmarks")
      } finally {
        setIsLoading(false)
      }
    }

    fetchBookmarks()
  }, [])

  const removeBookmark = async (tripId: number) => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) return

      const { error: deleteError } = await supabase
        .from("saved_trips")
        .delete()
        .eq("user_id", user.id)
        .eq("trip_id", tripId)

      if (deleteError) throw deleteError

      setBookmarkedTrips((prev) => prev.filter((b) => b.trips.id !== tripId))
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to remove bookmark")
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-foreground">Saved Trips</h1>
          <p className="text-muted-foreground">Trips you bookmarked for later</p>
        </div>

        {isLoading && <p className="text-muted-foreground">Loading bookmarks...</p>}

        {error && (
          <div className="bg-destructive/10 border border-destructive/30 text-destructive p-3 rounded-md">{error}</div>
        )}

        {!isLoading && bookmarkedTrips.length === 0 && (
          <Card className="p-12 text-center border-border">
            <Heart size={48} className="mx-auto mb-4 text-muted-foreground/50" />
            <p className="text-lg font-medium text-foreground mb-2">No bookmarks yet</p>
            <p className="text-muted-foreground mb-6">Start saving trips to view them here later</p>
            <Button asChild className="bg-primary hover:bg-primary/90">
              <Link href="/dashboard">Explore Trips</Link>
            </Button>
          </Card>
        )}

        {!isLoading && bookmarkedTrips.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {bookmarkedTrips.map(({ trip_id, trips: trip }) => (
              <Card key={trip_id} className="overflow-hidden hover:shadow-lg transition-shadow bg-card border-border">
                {/* Image */}
                <div className="relative h-48 bg-muted overflow-hidden">
                  <img
                    src={trip.image || "/placeholder.svg"}
                    alt={trip.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform"
                  />
                  <div className="absolute top-3 right-3 bg-black/60 px-3 py-1 rounded-full">
                    <p className="text-white font-medium text-sm">{trip.price}</p>
                  </div>
                </div>

                {/* Content */}
                <div className="p-4 space-y-3">
                  <div>
                    <h3 className="text-lg font-bold text-foreground line-clamp-2">{trip.title}</h3>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                      <MapPin size={16} />
                      {trip.destination}
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2">
                    {trip.tags?.map((tag: string) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  {/* Trip Info */}
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Calendar size={16} />
                      {trip.dates}
                    </div>
                    <div className="flex items-center gap-2">
                      <Users size={16} />
                      {trip.travelers}/{trip.maxTravelers} travelers
                    </div>
                  </div>

                  {/* Creator */}
                  <div className="pt-2 border-t border-border">
                    <p className="text-sm font-medium text-foreground">
                      {trip.creator}
                      <span className="text-primary ml-1">★ {trip.trustScore}%</span>
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-4">
                    <Button asChild className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground">
                      <Link href={`/trip/${trip.id}`}>View Trip</Link>
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeBookmark(trip.id)}
                      className="text-primary hover:bg-primary/10"
                    >
                      <Heart size={20} fill="currentColor" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
