import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase/server"
import { DashboardLayout } from "@/components/dashboard-layout"
import { TripFeed } from "@/components/trip-feed"

export default async function DashboardPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-foreground">Discover Trips</h1>
          <p className="text-muted-foreground">Find travel companions and join upcoming adventures</p>
        </div>
        <TripFeed />
      </div>
    </DashboardLayout>
  )
}
