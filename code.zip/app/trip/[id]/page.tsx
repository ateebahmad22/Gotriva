import Link from "next/link"
import { DashboardLayout } from "@/components/dashboard-layout"
import { TripDetailView } from "@/components/trip-detail-view"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function TripDetailPage({ params }: { params: { id: string } }) {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <Button asChild variant="ghost" className="pl-0 hover:bg-transparent">
          <Link href="/dashboard" className="flex items-center gap-2">
            <ArrowLeft size={20} />
            Back to Trips
          </Link>
        </Button>
        <TripDetailView tripId={params.id} />
      </div>
    </DashboardLayout>
  )
}
