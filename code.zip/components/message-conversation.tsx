"use client"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, Send, Phone, Video, MoreVertical } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"

interface Message {
  id: string
  sender: string
  content: string
  timestamp: string
  isOwn: boolean
}

// Mock messages
const mockMessages: Record<string, Message[]> = {
  "alex-k": [
    {
      id: "1",
      sender: "Alex K.",
      content: "Hey! I'm so excited about the Japan trip next spring!",
      timestamp: "10:30 AM",
      isOwn: false,
    },
    {
      id: "2",
      sender: "You",
      content: "Me too! Have you been to Japan before?",
      timestamp: "10:32 AM",
      isOwn: true,
    },
    {
      id: "3",
      sender: "Alex K.",
      content: "No, first time! I'm really looking forward to the cherry blossoms and the temples in Kyoto.",
      timestamp: "10:35 AM",
      isOwn: false,
    },
    {
      id: "4",
      sender: "You",
      content:
        "That sounds amazing! I have some great recommendations for both. When should we finalize the itinerary?",
      timestamp: "10:37 AM",
      isOwn: true,
    },
    {
      id: "5",
      sender: "Alex K.",
      content:
        "Excited about the Japan trip! When should we meet? I think we should coordinate with the other group members too.",
      timestamp: "10:42 AM",
      isOwn: false,
    },
  ],
}

export function MessageConversation({ username }: { username: string }) {
  const [messages, setMessages] = useState<Message[]>(mockMessages[username] || mockMessages["alex-k"])
  const [inputValue, setInputValue] = useState("")
  const [isSending, setIsSending] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return

    setIsSending(true)

    const newMessage: Message = {
      id: Date.now().toString(),
      sender: "You",
      content: inputValue,
      timestamp: new Date().toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      }),
      isOwn: true,
    }

    setMessages((prev) => [...prev, newMessage])
    setInputValue("")

    // Simulate response
    setTimeout(() => {
      const responseMessage: Message = {
        id: Date.now().toString(),
        sender: username
          .split("-")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" "),
        content: "That sounds great! Looking forward to chatting more.",
        timestamp: new Date().toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          hour12: true,
        }),
        isOwn: false,
      }
      setMessages((prev) => [...prev, responseMessage])
      setIsSending(false)
    }, 1000)
  }

  const formattedUsername = username
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")

  return (
    <div className="flex flex-col h-[calc(100vh-200px)] rounded-lg overflow-hidden border border-border bg-card">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border bg-card">
        <div className="flex items-center gap-4">
          <Link href="/messages" className="lg:hidden p-2 hover:bg-muted rounded-lg transition">
            <ArrowLeft size={20} />
          </Link>
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10">
              <AvatarFallback>{formattedUsername[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-semibold text-foreground">{formattedUsername}</h2>
              <p className="text-xs text-primary">Online</p>
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          <Button variant="ghost" size="icon" className="hover:bg-muted">
            <Phone size={20} />
          </Button>
          <Button variant="ghost" size="icon" className="hover:bg-muted">
            <Video size={20} />
          </Button>
          <Button variant="ghost" size="icon" className="hover:bg-muted">
            <MoreVertical size={20} />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div ref={scrollRef} className="space-y-4 pr-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.isOwn ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-xs px-4 py-2 rounded-lg ${
                  message.isOwn
                    ? "bg-primary text-primary-foreground rounded-br-none"
                    : "bg-muted text-foreground rounded-bl-none"
                }`}
              >
                <p className="break-words">{message.content}</p>
                <p className={`text-xs mt-1 ${message.isOwn ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                  {message.timestamp}
                </p>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t border-border bg-card">
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder="Type your message..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                handleSendMessage()
              }
            }}
            disabled={isSending}
            className="bg-background border-border"
          />
          <Button
            onClick={handleSendMessage}
            disabled={isSending || !inputValue.trim()}
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <Send size={18} />
          </Button>
        </div>
      </div>
    </div>
  )
}
