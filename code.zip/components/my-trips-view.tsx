"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { MapPin, Users, Calendar, CheckCircle, Clock, AlertCircle } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { createClient } from "@/lib/supabase/client"

interface TripEntry {
  id: string
  title: string
  destination: string
  image: string
  dates: string
  status: "completed" | "upcoming" | "pending"
  role: "organizer" | "participant"
  travelers: number
  maxTravelers: number
}

const getStatusIcon = (status: string) => {
  switch (status) {
    case "completed":
      return <CheckCircle size={18} className="text-primary" />
    case "upcoming":
      return <Clock size={18} className="text-primary" />
    case "pending":
      return <AlertCircle size={18} className="text-yellow-500" />
    default:
      return null
  }
}

const getStatusBadge = (status: string) => {
  switch (status) {
    case "completed":
      return <Badge className="bg-primary/20 text-primary">Completed</Badge>
    case "upcoming":
      return <Badge className="bg-blue-500/20 text-blue-600">Upcoming</Badge>
    case "pending":
      return <Badge className="bg-yellow-500/20 text-yellow-600">Pending</Badge>
    default:
      return null
  }
}

export function MyTripsView() {
  const [trips, setTrips] = useState<TripEntry[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    const fetchTrips = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) return

        const { data: orgTrips } = await supabase.from("trips").select("*").eq("organizer_id", user.id)

        const { data: joinedData } = await supabase.from("trip_participants").select("trips(*)").eq("user_id", user.id)

        const organizedTrips =
          orgTrips?.map((trip) => ({
            id: trip.id,
            title: trip.title,
            destination: trip.destination,
            image: trip.thumbnail_url || "/placeholder.svg",
            dates: `${new Date(trip.start_date).toLocaleDateString()} - ${new Date(trip.end_date).toLocaleDateString()}`,
            status: trip.status === "planning" ? "pending" : trip.status,
            role: "organizer" as const,
            travelers: trip.current_participants,
            maxTravelers: trip.max_participants,
          })) || []

        const participatingTrips =
          joinedData?.map((p: any) => ({
            id: p.trips.id,
            title: p.trips.title,
            destination: p.trips.destination,
            image: p.trips.thumbnail_url || "/placeholder.svg",
            dates: `${new Date(p.trips.start_date).toLocaleDateString()} - ${new Date(p.trips.end_date).toLocaleDateString()}`,
            status: p.trips.status === "planning" ? "pending" : p.trips.status,
            role: "participant" as const,
            travelers: p.trips.current_participants,
            maxTravelers: p.trips.max_participants,
          })) || []

        setTrips([...organizedTrips, ...participatingTrips])
      } catch (error) {
        console.error("Failed to fetch trips:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchTrips()
  }, [supabase])

  if (isLoading) {
    return <div className="text-center py-12">Loading trips...</div>
  }

  const organizedTrips = trips.filter((t) => t.role === "organizer")
  const participatingTrips = trips.filter((t) => t.role === "participant")

  const TripCard = ({ trip }: { trip: TripEntry }) => (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow bg-card border-border">
      <div className="relative h-40 bg-muted overflow-hidden">
        <img src={trip.image || "/placeholder.svg"} alt={trip.title} className="w-full h-full object-cover" />
        <div className="absolute top-3 right-3">{getStatusBadge(trip.status)}</div>
      </div>

      <div className="p-4 space-y-3">
        <h3 className="font-bold text-foreground line-clamp-2">{trip.title}</h3>

        <div className="space-y-2 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <MapPin size={16} />
            {trip.destination}
          </div>
          <div className="flex items-center gap-2">
            <Calendar size={16} />
            {trip.dates}
          </div>
          <div className="flex items-center gap-2">
            <Users size={16} />
            {trip.travelers}/{trip.maxTravelers} travelers
          </div>
        </div>

        <div className="flex gap-2 pt-3">
          <Button asChild variant="outline" className="flex-1 border-border bg-transparent">
            <Link href={`/trip/${trip.id}`}>View Trip</Link>
          </Button>
          {trip.role === "organizer" && (
            <Button asChild className="flex-1 bg-primary hover:bg-primary/90">
              <Link href={`/trip/${trip.id}/manage`}>Manage</Link>
            </Button>
          )}
        </div>
      </div>
    </Card>
  )

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-foreground">My Trips</h1>
        <p className="text-muted-foreground">Manage your trips and view trip details</p>
      </div>

      <Tabs defaultValue="organized" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-muted">
          <TabsTrigger value="organized">Organized ({organizedTrips.length})</TabsTrigger>
          <TabsTrigger value="participating">Participating ({participatingTrips.length})</TabsTrigger>
          <TabsTrigger value="all">All ({trips.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="organized" className="space-y-6">
          {organizedTrips.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {organizedTrips.map((trip) => (
                <TripCard key={trip.id} trip={trip} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              You haven't organized any trips yet. Create one to get started!
            </div>
          )}
        </TabsContent>

        <TabsContent value="participating" className="space-y-6">
          {participatingTrips.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {participatingTrips.map((trip) => (
                <TripCard key={trip.id} trip={trip} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              You haven't joined any trips yet. Explore trips to get started!
            </div>
          )}
        </TabsContent>

        <TabsContent value="all" className="space-y-6">
          {trips.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {trips.map((trip) => (
                <TripCard key={trip.id} trip={trip} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">No trips found.</div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
