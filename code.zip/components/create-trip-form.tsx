"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { createClient } from "@/lib/supabase/client"

const TRIP_CATEGORIES = [
  "Adventure",
  "Beach",
  "Culture",
  "Hiking",
  "Photography",
  "Food",
  "Road Trip",
  "Nature",
  "City Exploration",
  "Backpacking",
]

const BUDGET_RANGES = ["Under $500", "$500 - $1,000", "$1,000 - $2,000", "$2,000 - $5,000", "$5,000+"]

export function CreateTripForm() {
  const [formData, setFormData] = useState({
    title: "",
    destination: "",
    startDate: "",
    endDate: "",
    description: "",
    maxTravelers: "4",
    budget: "",
    difficulty: "Moderate",
    selectedCategories: [] as string[],
    itinerary: "",
    accommodations: "",
    requirements: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()
  const supabase = createClient()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.currentTarget
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSelectChange = (value: string, field: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const toggleCategory = (category: string) => {
    setFormData((prev) => ({
      ...prev,
      selectedCategories: prev.selectedCategories.includes(category)
        ? prev.selectedCategories.filter((c) => c !== category)
        : [...prev.selectedCategories, category],
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsSubmitting(true)

    try {
      // Validation
      if (!formData.title || !formData.destination || !formData.startDate || !formData.endDate) {
        throw new Error("Please fill in all required fields")
      }
      if (new Date(formData.endDate) <= new Date(formData.startDate)) {
        throw new Error("End date must be after start date")
      }
      if (formData.selectedCategories.length === 0) {
        throw new Error("Please select at least one category")
      }
      if (!formData.budget) {
        throw new Error("Please select a budget range")
      }

      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Not authenticated")

      const { error: tripError } = await supabase.from("trips").insert({
        organizer_id: user.id,
        title: formData.title,
        description: formData.description,
        destination: formData.destination,
        start_date: formData.startDate,
        end_date: formData.endDate,
        difficulty_level: formData.difficulty,
        max_participants: Number.parseInt(formData.maxTravelers),
        itinerary: formData.itinerary.split("\n").filter((i) => i.trim()),
        trip_type: formData.selectedCategories,
      })

      if (tripError) throw tripError

      router.push("/my-trips")
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="border border-border bg-card p-6 space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Info */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Trip Details</h3>

          <div className="space-y-2">
            <Label htmlFor="title" className="text-foreground font-medium">
              Trip Title *
            </Label>
            <Input
              id="title"
              name="title"
              placeholder="e.g., Thailand Island Hopping Adventure"
              value={formData.title}
              onChange={handleChange}
              disabled={isSubmitting}
              className="bg-background border-border"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="destination" className="text-foreground font-medium">
              Destination *
            </Label>
            <Input
              id="destination"
              name="destination"
              placeholder="e.g., Phuket, Thailand"
              value={formData.destination}
              onChange={handleChange}
              disabled={isSubmitting}
              className="bg-background border-border"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate" className="text-foreground font-medium">
                Start Date *
              </Label>
              <Input
                id="startDate"
                name="startDate"
                type="date"
                value={formData.startDate}
                onChange={handleChange}
                disabled={isSubmitting}
                className="bg-background border-border"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endDate" className="text-foreground font-medium">
                End Date *
              </Label>
              <Input
                id="endDate"
                name="endDate"
                type="date"
                value={formData.endDate}
                onChange={handleChange}
                disabled={isSubmitting}
                className="bg-background border-border"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-foreground font-medium">
              Trip Description *
            </Label>
            <Textarea
              id="description"
              name="description"
              placeholder="Describe your trip, what you plan to do, what you're looking for in travel companions..."
              value={formData.description}
              onChange={handleChange}
              disabled={isSubmitting}
              className="bg-background border-border min-h-24"
            />
          </div>
        </div>

        {/* Trip Preferences */}
        <div className="space-y-4 pt-4 border-t border-border">
          <h3 className="text-lg font-semibold text-foreground">Trip Preferences</h3>

          <div className="space-y-2">
            <Label className="text-foreground font-medium">Trip Categories *</Label>
            <div className="flex flex-wrap gap-2">
              {TRIP_CATEGORIES.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => toggleCategory(category)}
                  className={`px-4 py-2 rounded-lg border-2 transition ${
                    formData.selectedCategories.includes(category)
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-background text-foreground hover:border-primary"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="difficulty" className="text-foreground font-medium">
                Difficulty Level
              </Label>
              <Select value={formData.difficulty} onValueChange={(value) => handleSelectChange(value, "difficulty")}>
                <SelectTrigger className="bg-background border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Relaxed">Relaxed</SelectItem>
                  <SelectItem value="Moderate">Moderate</SelectItem>
                  <SelectItem value="Challenging">Challenging</SelectItem>
                  <SelectItem value="Extreme">Extreme</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxTravelers" className="text-foreground font-medium">
                Max Travelers
              </Label>
              <Input
                id="maxTravelers"
                name="maxTravelers"
                type="number"
                min="2"
                max="20"
                value={formData.maxTravelers}
                onChange={handleChange}
                disabled={isSubmitting}
                className="bg-background border-border"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="budget" className="text-foreground font-medium">
              Budget Range *
            </Label>
            <Select value={formData.budget} onValueChange={(value) => handleSelectChange(value, "budget")}>
              <SelectTrigger className="bg-background border-border">
                <SelectValue placeholder="Select budget range" />
              </SelectTrigger>
              <SelectContent>
                {BUDGET_RANGES.map((range) => (
                  <SelectItem key={range} value={range}>
                    {range}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Itinerary & Details */}
        <div className="space-y-4 pt-4 border-t border-border">
          <h3 className="text-lg font-semibold text-foreground">Additional Information</h3>

          <div className="space-y-2">
            <Label htmlFor="itinerary" className="text-foreground font-medium">
              Planned Itinerary
            </Label>
            <Textarea
              id="itinerary"
              name="itinerary"
              placeholder="Day by day breakdown of activities and locations..."
              value={formData.itinerary}
              onChange={handleChange}
              disabled={isSubmitting}
              className="bg-background border-border min-h-24"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="accommodations" className="text-foreground font-medium">
              Accommodation Details
            </Label>
            <Textarea
              id="accommodations"
              name="accommodations"
              placeholder="Where will you stay? Will you share rooms? Budget for accommodation..."
              value={formData.accommodations}
              onChange={handleChange}
              disabled={isSubmitting}
              className="bg-background border-border min-h-20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="requirements" className="text-foreground font-medium">
              Requirements for Travelers
            </Label>
            <Textarea
              id="requirements"
              name="requirements"
              placeholder="Any requirements for fellow travelers? e.g., fitness level, vaccination status, travel insurance..."
              value={formData.requirements}
              onChange={handleChange}
              disabled={isSubmitting}
              className="bg-background border-border min-h-20"
            />
          </div>
        </div>

        {error && (
          <div className="bg-destructive/10 border border-destructive/30 text-destructive p-4 rounded-lg">{error}</div>
        )}

        <div className="flex gap-4 pt-4">
          <Button
            type="submit"
            disabled={isSubmitting}
            className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
          >
            {isSubmitting ? "Creating Trip..." : "Create Trip"}
          </Button>
          <Button
            type="button"
            variant="outline"
            disabled={isSubmitting}
            className="border-border bg-transparent"
            onClick={() => window.history.back()}
          >
            Cancel
          </Button>
        </div>
      </form>
    </Card>
  )
}
