"use client"

import { type ReactNode, useState } from "react"
import Link from "next/link"
import { Menu, X, Bell, MessageSquare, User, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface DashboardLayoutProps {
  children: ReactNode
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const handleLogout = async () => {
    try {
      const response = await fetch("/api/auth/logout", { method: "POST" })
      if (response.ok) {
        window.location.href = "/"
      }
    } catch (error) {
      console.error("Logout failed:", error)
      window.location.href = "/"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="text-2xl font-bold text-primary">
            GOTRIVA
          </Link>

          {/* Mobile Menu Button */}
          <button className="md:hidden p-2" onClick={() => setSidebarOpen(!sidebarOpen)} aria-label="Toggle sidebar">
            {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          {/* Header Actions */}
          <div className="hidden md:flex items-center gap-4">
            <Button asChild variant="ghost" size="icon" className="relative hover:bg-muted">
              <Link href="#notifications">
                <Bell size={20} />
                <span className="absolute top-1 right-1 w-2 h-2 bg-primary rounded-full"></span>
              </Link>
            </Button>

            <Button asChild variant="ghost" size="icon" className="hover:bg-muted">
              <Link href="/messages">
                <MessageSquare size={20} />
              </Link>
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="hover:bg-muted">
                  <User size={20} />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem asChild>
                  <Link href="/profile">Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings">Settings</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                  <LogOut size={16} className="mr-2" />
                  Log Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`${sidebarOpen ? "block" : "hidden"} md:block w-full md:w-64 bg-card border-r border-border`}>
          <nav className="p-4 space-y-2">
            <Link href="/dashboard" className="block px-4 py-3 rounded-lg bg-primary/10 text-primary font-medium">
              Discover
            </Link>
            <Link href="/my-trips" className="block px-4 py-3 rounded-lg hover:bg-muted text-foreground transition">
              My Trips
            </Link>
            <Link href="/bookmarks" className="block px-4 py-3 rounded-lg hover:bg-muted text-foreground transition">
              Bookmarks
            </Link>
            <Link href="/messages" className="block px-4 py-3 rounded-lg hover:bg-muted text-foreground transition">
              Messages
            </Link>
          </nav>

          {/* Sidebar Footer */}
          <div className="absolute bottom-4 left-4 right-4 md:static md:p-4 md:mt-8 border-t border-border pt-4 md:border-0">
            <Card className="bg-primary/5 border-primary/20 p-4 space-y-2">
              <p className="text-sm font-medium text-foreground">Create a Trip</p>
              <p className="text-xs text-muted-foreground">Share your adventure and find travel companions</p>
              <Button asChild className="w-full bg-primary hover:bg-primary/90">
                <Link href="/create-trip">Create Trip</Link>
              </Button>
            </Card>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <div className="max-w-6xl mx-auto px-4 py-8">{children}</div>
        </main>
      </div>
    </div>
  )
}

export default DashboardLayout
