"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"

const LANGUAGES = ["English", "Spanish", "French", "German", "Mandarin", "Japanese", "Portuguese"]
const INTERESTS = [
  "Adventure",
  "Beach",
  "Culture",
  "Hiking",
  "Photography",
  "Food",
  "Road Trip",
  "Nature",
  "City Exploration",
  "Backpacking",
  "Wildlife",
  "History",
]

export function EditProfileForm() {
  const [formData, setFormData] = useState({
    name: "",
    bio: "",
    location: "",
    email: "",
    phone: "",
    selectedLanguages: [] as string[],
    selectedInterests: [] as string[],
  })

  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) return

        const { data } = await supabase.from("users").select("*").eq("id", user.id).single()

        if (data) {
          setFormData({
            name: data.full_name || "",
            bio: data.bio || "",
            location: "",
            email: data.email,
            phone: "",
            selectedLanguages: data.languages || [],
            selectedInterests: data.interests || [],
          })
        }
      } catch (error) {
        console.error("Failed to fetch profile:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchProfile()
  }, [supabase])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.currentTarget
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const toggleLanguage = (lang: string) => {
    setFormData((prev) => ({
      ...prev,
      selectedLanguages: prev.selectedLanguages.includes(lang)
        ? prev.selectedLanguages.filter((l) => l !== lang)
        : [...prev.selectedLanguages, lang],
    }))
  }

  const toggleInterest = (interest: string) => {
    setFormData((prev) => ({
      ...prev,
      selectedInterests: prev.selectedInterests.includes(interest)
        ? prev.selectedInterests.filter((i) => i !== interest)
        : [...prev.selectedInterests, interest],
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")
    setIsSubmitting(true)

    try {
      if (!formData.name || !formData.bio) {
        throw new Error("Please fill in all required fields")
      }

      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Not authenticated")

      const { error: updateError } = await supabase
        .from("users")
        .update({
          full_name: formData.name,
          bio: formData.bio,
          languages: formData.selectedLanguages,
          interests: formData.selectedInterests,
        })
        .eq("id", user.id)

      if (updateError) throw updateError

      setSuccess("Profile updated successfully!")
      setTimeout(() => router.push("/profile"), 1500)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return <div className="text-center py-12">Loading profile...</div>
  }

  return (
    <Card className="border border-border bg-card p-6 space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Info */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Basic Information</h3>

          <div className="space-y-2">
            <Label htmlFor="name" className="text-foreground font-medium">
              Full Name *
            </Label>
            <Input
              id="name"
              name="name"
              placeholder="Your name"
              value={formData.name}
              onChange={handleChange}
              disabled={isSubmitting}
              className="bg-background border-border"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email" className="text-foreground font-medium">
              Email Address
            </Label>
            <Input
              id="email"
              name="email"
              type="email"
              placeholder="your@email.com"
              value={formData.email}
              onChange={handleChange}
              disabled={isSubmitting}
              className="bg-background border-border"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="location" className="text-foreground font-medium">
              Location *
            </Label>
            <Input
              id="location"
              name="location"
              placeholder="City, Country"
              value={formData.location}
              onChange={handleChange}
              disabled={isSubmitting}
              className="bg-background border-border"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone" className="text-foreground font-medium">
              Phone Number
            </Label>
            <Input
              id="phone"
              name="phone"
              type="tel"
              placeholder="Optional"
              value={formData.phone}
              onChange={handleChange}
              disabled={isSubmitting}
              className="bg-background border-border"
            />
          </div>
        </div>

        {/* Bio */}
        <div className="space-y-4 pt-4 border-t border-border">
          <h3 className="text-lg font-semibold text-foreground">About You</h3>

          <div className="space-y-2">
            <Label htmlFor="bio" className="text-foreground font-medium">
              Bio *
            </Label>
            <Textarea
              id="bio"
              name="bio"
              placeholder="Tell other travelers about yourself..."
              value={formData.bio}
              onChange={handleChange}
              disabled={isSubmitting}
              className="bg-background border-border min-h-24"
            />
            <p className="text-xs text-muted-foreground">{formData.bio.length}/500 characters</p>
          </div>
        </div>

        {/* Languages */}
        <div className="space-y-4 pt-4 border-t border-border">
          <h3 className="text-lg font-semibold text-foreground">Languages</h3>
          <div className="flex flex-wrap gap-2">
            {LANGUAGES.map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => toggleLanguage(lang)}
                className={`px-4 py-2 rounded-lg border-2 transition ${
                  formData.selectedLanguages.includes(lang)
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border bg-background text-foreground hover:border-primary"
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        {/* Interests */}
        <div className="space-y-4 pt-4 border-t border-border">
          <h3 className="text-lg font-semibold text-foreground">Travel Interests</h3>
          <div className="flex flex-wrap gap-2">
            {INTERESTS.map((interest) => (
              <button
                key={interest}
                type="button"
                onClick={() => toggleInterest(interest)}
                className={`px-4 py-2 rounded-lg border-2 transition ${
                  formData.selectedInterests.includes(interest)
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border bg-background text-foreground hover:border-primary"
                }`}
              >
                {interest}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="bg-destructive/10 border border-destructive/30 text-destructive p-4 rounded-lg">{error}</div>
        )}

        {success && <div className="bg-primary/10 border border-primary text-primary p-4 rounded-lg">{success}</div>}

        <div className="flex gap-4 pt-4">
          <Button
            type="submit"
            disabled={isSubmitting}
            className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
          >
            {isSubmitting ? "Saving..." : "Save Changes"}
          </Button>
          <Button
            type="button"
            variant="outline"
            disabled={isSubmitting}
            className="border-border bg-transparent"
            onClick={() => window.history.back()}
          >
            Cancel
          </Button>
        </div>
      </form>
    </Card>
  )
}
