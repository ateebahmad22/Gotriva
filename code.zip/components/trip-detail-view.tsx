"use client"

import { useState } from "react"
import Link from "next/link"
import { Calendar, Star, Share2, MessageCircle } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

interface TripDetail {
  id: string
  title: string
  destination: string
  image: string
  dates: string
  startDate: string
  endDate: string
  travelers: number
  maxTravelers: number
  description: string
  itinerary: string
  accommodations: string
  requirements: string
  tags: string[]
  creator: {
    name: string
    avatar: string
    trustScore: number
    tripsCompleted: number
  }
  price: string
  difficulty: string
  budget: string
}

// Mock trip details
const mockTripDetail: Record<string, TripDetail> = {
  "1": {
    id: "1",
    title: "Thailand Island Hopping Adventure",
    destination: "Phuket, Thailand",
    image: "/placeholder.svg?key=9dtop",
    dates: "Dec 20 - Jan 5",
    startDate: "2024-12-20",
    endDate: "2025-01-05",
    travelers: 4,
    maxTravelers: 6,
    description:
      "Join us for an unforgettable week exploring Thailand's most beautiful islands. We'll be island hopping from Phuket to Phi Phi Islands, Krabi, and more. Perfect for beach lovers and adventure seekers!",
    itinerary: `Day 1-2: Phuket arrival and exploration
Day 3-4: Phi Phi Islands
Day 5: Rock climbing in Krabi
Day 6-7: Railay Beach and island tours
Day 8: Return to Phuket`,
    accommodations:
      "Mix of beachfront bungalows and island resorts. We'll share rooms where possible to save costs. All accommodations are highly rated and verified.",
    requirements:
      "Comfortable with group activities, basic swimming ability preferred, open to trying new foods, travel insurance recommended.",
    tags: ["Beach", "Adventure", "Southeast Asia"],
    creator: {
      name: "Sarah M.",
      avatar: "/placeholder.svg?key=user1",
      trustScore: 98,
      tripsCompleted: 12,
    },
    price: "$1,200",
    difficulty: "Moderate",
    budget: "$1,000 - $2,000",
  },
}

export function TripDetailView({ tripId }: { tripId: string }) {
  const [isJoining, setIsJoining] = useState(false)
  const [hasJoined, setHasJoined] = useState(false)

  const trip = mockTripDetail[tripId] || mockTripDetail["1"]

  const handleJoinTrip = async () => {
    setIsJoining(true)
    try {
      // TODO: Send join request to backend
      console.log("Joining trip:", tripId)

      setTimeout(() => {
        setIsJoining(false)
        setHasJoined(true)
      }, 1000)
    } catch (error) {
      setIsJoining(false)
      console.error("Error joining trip:", error)
    }
  }

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <div className="relative h-96 rounded-lg overflow-hidden">
        <img src={trip.image || "/placeholder.svg"} alt={trip.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
          <div className="text-white space-y-2">
            <h1 className="text-4xl font-bold">{trip.title}</h1>
            <p className="text-lg opacity-90">{trip.destination}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 lg:grid-cols-6">
        <div className="grid lg:col-span-4 gap-6">
          {/* Trip Info Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-card border-border p-4 text-center space-y-2">
              <div className="text-2xl font-bold text-primary">{trip.price}</div>
              <p className="text-xs text-muted-foreground">Price per person</p>
            </Card>
            <Card className="bg-card border-border p-4 text-center space-y-2">
              <div className="flex items-center justify-center gap-1">
                <Calendar size={20} className="text-primary" />
              </div>
              <p className="text-sm font-medium text-foreground">{trip.dates}</p>
              <p className="text-xs text-muted-foreground">Duration</p>
            </Card>
            <Card className="bg-card border-border p-4 text-center space-y-2">
              <div className="text-2xl font-bold text-primary">{trip.maxTravelers - trip.travelers}</div>
              <p className="text-xs text-muted-foreground">Spots left</p>
            </Card>
            <Card className="bg-card border-border p-4 text-center space-y-2">
              <div className="text-lg font-bold text-primary">{trip.difficulty}</div>
              <p className="text-xs text-muted-foreground">Difficulty</p>
            </Card>
          </div>

          {/* Categories */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-foreground">Trip Highlights</h3>
            <div className="flex flex-wrap gap-2">
              {trip.tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="text-sm">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-foreground">About This Trip</h3>
            <p className="text-muted-foreground leading-relaxed">{trip.description}</p>
          </div>

          {/* Itinerary */}
          <Card className="bg-card border-border p-6 space-y-3">
            <h3 className="text-lg font-semibold text-foreground">Itinerary</h3>
            <div className="space-y-2 text-sm text-muted-foreground whitespace-pre-line">{trip.itinerary}</div>
          </Card>

          {/* Accommodations */}
          <Card className="bg-card border-border p-6 space-y-3">
            <h3 className="text-lg font-semibold text-foreground">Accommodations</h3>
            <p className="text-muted-foreground">{trip.accommodations}</p>
          </Card>

          {/* Requirements */}
          <Card className="bg-card border-border p-6 space-y-3">
            <h3 className="text-lg font-semibold text-foreground">Requirements</h3>
            <p className="text-muted-foreground">{trip.requirements}</p>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-2 space-y-4">
          {/* Creator Card */}
          <Card className="bg-card border-border p-6 space-y-4">
            <h3 className="font-semibold text-foreground">Trip Organizer</h3>

            <div className="flex items-center gap-3">
              <Avatar className="w-12 h-12">
                <AvatarFallback>{trip.creator.name[0]}</AvatarFallback>
              </Avatar>
              <div className="space-y-1">
                <p className="font-medium text-foreground">{trip.creator.name}</p>
                <div className="flex items-center gap-1 text-sm text-primary">
                  <Star size={14} fill="currentColor" />
                  {trip.creator.trustScore}% Trusted
                </div>
              </div>
            </div>

            <div className="text-sm text-muted-foreground space-y-2">
              <p>Completed {trip.creator.tripsCompleted} trips</p>
            </div>

            <Button asChild variant="outline" className="w-full border-border bg-transparent">
              <Link href={`/profile/${trip.creator.name}`}>View Profile</Link>
            </Button>
          </Card>

          {/* Action Buttons */}
          <Card className="bg-card border-border p-6 space-y-3">
            {!hasJoined ? (
              <Button
                onClick={handleJoinTrip}
                disabled={isJoining}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
              >
                {isJoining ? "Requesting..." : "Request to Join"}
              </Button>
            ) : (
              <div className="bg-primary/10 border border-primary text-primary p-3 rounded-lg text-center font-medium">
                Request Sent!
              </div>
            )}

            <Button variant="outline" className="w-full border-border bg-transparent" asChild>
              <Link href={`/messages/${trip.creator.name}`} className="flex items-center justify-center gap-2">
                <MessageCircle size={18} />
                Message
              </Link>
            </Button>

            <Button variant="outline" className="w-full border-border bg-transparent" size="icon">
              <Share2 size={18} />
            </Button>
          </Card>

          {/* Travelers */}
          <Card className="bg-card border-border p-6 space-y-3">
            <h3 className="font-semibold text-foreground">
              Travelers ({trip.travelers}/{trip.maxTravelers})
            </h3>
            <div className="space-y-2">
              {Array.from({ length: trip.travelers }).map((_, i) => (
                <div key={i} className="flex items-center gap-2 text-sm">
                  <Avatar className="w-8 h-8">
                    <AvatarFallback>T{i + 1}</AvatarFallback>
                  </Avatar>
                  <span className="text-muted-foreground">Traveler {i + 1}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
