import { Users, MapPin, Shield, MessageSquare } from "lucide-react"

const features = [
  {
    icon: MapPin,
    title: "Smart Trip Matching",
    description:
      "AI-powered algorithm connects you with travelers who share your interests, travel style, and destinations.",
  },
  {
    icon: Users,
    title: "Verified Community",
    description: "Background checks, verified reviews, and community trust scores ensure safe, authentic connections.",
  },
  {
    icon: MessageSquare,
    title: "Built-in Messaging",
    description: "Connect with potential travel companions directly on the platform before committing to a trip.",
  },
  {
    icon: Shield,
    title: "Travel Insurance",
    description: "Optional travel insurance coverage and emergency support throughout your journey.",
  },
]

export default function Features() {
  return (
    <section id="features" className="py-20 px-4 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
            Everything You Need for Group Adventures
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
            GOTRIVA brings together the tools and community for seamless, safe, and unforgettable travel experiences.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <div
                key={index}
                className="bg-card p-8 rounded-lg border border-border hover:border-primary/30 transition"
              >
                <Icon className="w-12 h-12 text-primary mb-4" />
                <h3 className="text-2xl font-bold text-foreground mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
