"use client"

import { useState } from "react"
import Link from "next/link"
import { Star, MapPin, Flag, Shield, Award } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface UserProfile {
  id: string
  name: string
  bio: string
  location: string
  joinDate: string
  avatar: string
  coverImage: string
  trustScore: number
  verificationStatus: "verified" | "pending" | "unverified"
  badges: Array<{
    name: string
    icon: string
    description: string
  }>
  tripsCompleted: number
  tripsAsOrganizer: number
  languages: string[]
  interests: string[]
  reviews: Array<{
    id: string
    author: string
    rating: number
    comment: string
    tripName: string
    date: string
  }>
  photos: string[]
}

// Mock profile data
const mockProfiles: Record<string, UserProfile> = {
  "sarah-m": {
    id: "1",
    name: "Sarah M.",
    bio: "Adventure seeker, travel photographer, and culture enthusiast. Always planning the next big trip!",
    location: "San Francisco, USA",
    joinDate: "2022-03-15",
    avatar: "/placeholder.svg?key=avatar1",
    coverImage: "/placeholder.svg?key=cover1",
    trustScore: 98,
    verificationStatus: "verified",
    badges: [
      {
        name: "Super Host",
        icon: "🏆",
        description: "Organized 10+ successful trips",
      },
      {
        name: "Verified Traveler",
        icon: "✓",
        description: "Identity verified through ID",
      },
      {
        name: "5-Star Organizer",
        icon: "⭐",
        description: "All trips rated 5 stars",
      },
    ],
    tripsCompleted: 28,
    tripsAsOrganizer: 12,
    languages: ["English", "Spanish", "French"],
    interests: ["Beach", "Photography", "Adventure", "Culture", "Hiking"],
    reviews: [
      {
        id: "1",
        author: "John D.",
        rating: 5,
        comment:
          "Amazing trip organizer! Everything was perfectly planned and Sarah was incredibly helpful throughout.",
        tripName: "Thailand Island Hopping",
        date: "2024-01-15",
      },
      {
        id: "2",
        author: "Emma L.",
        rating: 5,
        comment: "Sarah made everyone feel welcome and included. Great group dynamics and unforgettable memories!",
        tripName: "Morocco Cultural Tour",
        date: "2023-11-20",
      },
      {
        id: "3",
        author: "Mike T.",
        rating: 5,
        comment: "Professional, organized, and fun! Would definitely travel with Sarah again.",
        tripName: "Peru Adventure",
        date: "2023-09-10",
      },
    ],
    photos: ["/placeholder.svg?key=photo1", "/placeholder.svg?key=photo2", "/placeholder.svg?key=photo3"],
  },
}

export function UserProfileView({ username }: { username: string }) {
  const [isReporting, setIsReporting] = useState(false)
  const profile = mockProfiles[username] || mockProfiles["sarah-m"]

  const handleReport = async () => {
    setIsReporting(true)
    // TODO: Send report to backend
    console.log("Reporting profile:", username)
    setTimeout(() => {
      setIsReporting(false)
      alert("Report submitted. Thank you for helping keep our community safe.")
    }, 1000)
  }

  const averageRating =
    profile.reviews.length > 0
      ? (profile.reviews.reduce((sum, r) => sum + r.rating, 0) / profile.reviews.length).toFixed(1)
      : 0

  return (
    <div className="space-y-6">
      {/* Cover Image */}
      <div className="relative h-48 bg-muted rounded-lg overflow-hidden">
        <img src={profile.coverImage || "/placeholder.svg"} alt="Cover" className="w-full h-full object-cover" />
      </div>

      {/* Profile Header */}
      <div className="relative space-y-6 -mt-20 px-6">
        <div className="flex flex-col md:flex-row md:items-end gap-4 justify-between">
          <div className="flex items-end gap-4">
            <Avatar className="w-32 h-32 border-4 border-background">
              <AvatarFallback className="text-2xl">{profile.name[0]}</AvatarFallback>
            </Avatar>
            <div className="space-y-2 mb-2">
              <h1 className="text-3xl font-bold text-foreground">{profile.name}</h1>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <Star size={18} className="text-primary fill-primary" />
                  <span className="font-semibold text-foreground">{profile.trustScore}%</span>
                </div>
                {profile.verificationStatus === "verified" && (
                  <Badge className="bg-primary/20 text-primary border-primary">
                    <Shield size={14} className="mr-1" />
                    Verified
                  </Badge>
                )}
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <Button asChild className="bg-primary hover:bg-primary/90">
              <Link href={`/messages/${username}`}>Message</Link>
            </Button>
            <Button
              variant="outline"
              className="border-destructive text-destructive hover:bg-destructive/10 bg-transparent"
              onClick={handleReport}
              disabled={isReporting}
            >
              <Flag size={18} className="mr-2" />
              {isReporting ? "Reporting..." : "Report"}
            </Button>
          </div>
        </div>

        {/* Bio */}
        <div className="max-w-2xl">
          <p className="text-muted-foreground text-lg">{profile.bio}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-card border-border p-4 space-y-1">
            <div className="text-2xl font-bold text-primary">{profile.tripsCompleted}</div>
            <p className="text-sm text-muted-foreground">Trips Joined</p>
          </Card>
          <Card className="bg-card border-border p-4 space-y-1">
            <div className="text-2xl font-bold text-primary">{profile.tripsAsOrganizer}</div>
            <p className="text-sm text-muted-foreground">Trips Organized</p>
          </Card>
          <Card className="bg-card border-border p-4 space-y-1">
            <div className="text-2xl font-bold text-primary">{averageRating}</div>
            <p className="text-sm text-muted-foreground">Avg. Rating</p>
          </Card>
          <Card className="bg-card border-border p-4 space-y-1">
            <div className="flex items-center gap-1">
              <MapPin size={18} className="text-primary" />
              <span className="text-foreground">{profile.location}</span>
            </div>
            <p className="text-sm text-muted-foreground">Based in</p>
          </Card>
        </div>

        {/* Badges */}
        {profile.badges.length > 0 && (
          <Card className="bg-card border-border p-6 space-y-4">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <Award size={20} />
              Badges & Achievements
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {profile.badges.map((badge, idx) => (
                <div key={idx} className="bg-muted p-4 rounded-lg space-y-2 text-center">
                  <div className="text-3xl">{badge.icon}</div>
                  <p className="font-medium text-foreground">{badge.name}</p>
                  <p className="text-sm text-muted-foreground">{badge.description}</p>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* About & Details */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="bg-card border-border p-6 space-y-4">
            <h3 className="text-lg font-semibold text-foreground">About</h3>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-muted-foreground">Joined</p>
                <p className="text-foreground">{new Date(profile.joinDate).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-2">Languages</p>
                <div className="flex flex-wrap gap-2">
                  {profile.languages.map((lang) => (
                    <Badge key={lang} variant="secondary">
                      {lang}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-2">Interests</p>
                <div className="flex flex-wrap gap-2">
                  {profile.interests.map((interest) => (
                    <Badge key={interest} variant="outline">
                      {interest}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </Card>

          <Card className="bg-card border-border p-6 space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Trust & Verification</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Identity Verified</span>
                <Badge className="bg-primary/20 text-primary">✓ Verified</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Community Rating</span>
                <span className="font-semibold text-primary">{profile.trustScore}%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Response Time</span>
                <span className="font-medium text-foreground">2-4 hours</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Reviews and Activity */}
        <Tabs defaultValue="reviews" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-muted">
            <TabsTrigger value="reviews">Reviews ({profile.reviews.length})</TabsTrigger>
            <TabsTrigger value="photos">Photos ({profile.photos.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="reviews" className="space-y-4">
            {profile.reviews.map((review) => (
              <Card key={review.id} className="bg-card border-border p-6 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-semibold text-foreground">{review.author}</p>
                    <p className="text-sm text-muted-foreground">{review.tripName}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: review.rating }).map((_, i) => (
                      <Star key={i} size={16} className="text-primary fill-primary" />
                    ))}
                  </div>
                </div>
                <p className="text-muted-foreground">{review.comment}</p>
                <p className="text-xs text-muted-foreground">{new Date(review.date).toLocaleDateString()}</p>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="photos" className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {profile.photos.map((photo, idx) => (
              <img
                key={idx}
                src={photo || "/placeholder.svg"}
                alt={`Photo ${idx + 1}`}
                className="w-full h-48 object-cover rounded-lg"
              />
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
