import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Hero() {
  return (
    <section className="min-h-screen bg-gradient-to-br from-background via-background to-background flex items-center justify-center px-4 py-20">
      <div className="max-w-4xl mx-auto text-center space-y-8">
        <div className="space-y-4">
          <h1 className="text-5xl md:text-7xl font-bold text-foreground text-balance">Travel with Your Tribe</h1>
          <p className="text-xl md:text-2xl text-muted-foreground text-balance">
            Find trusted travel companions, discover epic adventures, and build connections that last beyond the trip.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
            <Link href="/signup">Start Exploring</Link>
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="border-primary text-primary hover:bg-primary/10 bg-transparent"
          >
            <Link href="#how-it-works">Learn More</Link>
          </Button>
        </div>

        <div className="pt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-card p-6 rounded-lg border border-border">
            <div className="text-3xl font-bold text-primary mb-2">50K+</div>
            <p className="text-muted-foreground">Active Travelers</p>
          </div>
          <div className="bg-card p-6 rounded-lg border border-border">
            <div className="text-3xl font-bold text-primary mb-2">180+</div>
            <p className="text-muted-foreground">Countries Connected</p>
          </div>
          <div className="bg-card p-6 rounded-lg border border-border">
            <div className="text-3xl font-bold text-primary mb-2">98%</div>
            <p className="text-muted-foreground">Trust Score Average</p>
          </div>
        </div>
      </div>
    </section>
  )
}
