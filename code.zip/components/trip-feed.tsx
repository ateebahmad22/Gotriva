"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { MapPin, Users, Calendar, Heart, Share2 } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { createClient } from "@/lib/supabase/client"

// Mock trip data
const mockTrips = [
  {
    id: 1,
    title: "Thailand Island Hopping Adventure",
    destination: "Phuket, Thailand",
    image: "/thailand-island-hopping.jpg",
    dates: "Dec 20 - Jan 5",
    travelers: 4,
    maxTravelers: 6,
    description: "Join us for an unforgettable week exploring Thailand's most beautiful islands.",
    tags: ["Beach", "Adventure", "Southeast Asia"],
    creator: "Sarah M.",
    trustScore: 98,
    price: "$1,200",
  },
  {
    id: 2,
    title: "Japan Cherry Blossom Tour",
    destination: "Tokyo, Japan",
    image: "/japan-cherry-blossom.jpg",
    dates: "Mar 25 - Apr 10",
    travelers: 3,
    maxTravelers: 5,
    description: "Experience the magical cherry blossom season across Japan with experienced travelers.",
    tags: ["Culture", "Photography", "Asia"],
    creator: "Alex K.",
    trustScore: 95,
    price: "$1,800",
  },
  {
    id: 3,
    title: "Peru - Machu Picchu & Amazon",
    destination: "Cusco, Peru",
    image: "/peru-machu-picchu.png",
    dates: "Feb 10 - Feb 25",
    travelers: 5,
    maxTravelers: 8,
    description: "Trek to Machu Picchu and explore the Amazon rainforest on this epic South American journey.",
    tags: ["Hiking", "Nature", "South America"],
    creator: "James R.",
    trustScore: 97,
    price: "$1,600",
  },
  {
    id: 4,
    title: "Iceland Road Trip",
    destination: "Reykjavik, Iceland",
    image: "/iceland-road-trip-landscape.jpg",
    dates: "Jun 1 - Jun 15",
    travelers: 2,
    maxTravelers: 4,
    description: "Drive the Ring Road and discover Iceland's waterfalls, glaciers, and hot springs.",
    tags: ["Road Trip", "Nature", "Europe"],
    creator: "Emma L.",
    trustScore: 99,
    price: "$1,400",
  },
  {
    id: 5,
    title: "Morocco Cultural Immersion",
    destination: "Marrakech, Morocco",
    image: "/morocco-marrakech-medina.jpg",
    dates: "Apr 5 - Apr 20",
    travelers: 6,
    maxTravelers: 8,
    description: "Explore bustling medinas, ride camels through the Sahara, and stay in authentic riads.",
    tags: ["Culture", "Adventure", "Africa"],
    creator: "Hassan M.",
    trustScore: 96,
    price: "$1,100",
  },
  {
    id: 6,
    title: "New Zealand Adventure",
    destination: "Auckland, New Zealand",
    image: "/new-zealand-adventure.jpg",
    dates: "Jul 20 - Aug 10",
    travelers: 4,
    maxTravelers: 6,
    description: "Bungee jumping, hiking, and exploring the stunning landscapes of New Zealand.",
    tags: ["Adventure", "Hiking", "Oceania"],
    creator: "Mike T.",
    trustScore: 94,
    price: "$2,000",
  },
]

export function TripFeed() {
  const [savedTrips, setSavedTrips] = useState<number[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    const loadSavedTrips = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (!user) {
          setIsLoading(false)
          return
        }

        const { data } = await supabase.from("saved_trips").select("trip_id").eq("user_id", user.id)

        if (data) {
          setSavedTrips(data.map((s: { trip_id: number }) => s.trip_id))
        }
      } catch (error) {
        console.error("Error loading saved trips:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadSavedTrips()
  }, [])

  const toggleSave = async (tripId: number) => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        window.location.href = "/login"
        return
      }

      if (savedTrips.includes(tripId)) {
        await supabase.from("saved_trips").delete().eq("user_id", user.id).eq("trip_id", tripId)
        setSavedTrips((prev) => prev.filter((id) => id !== tripId))
      } else {
        await supabase.from("saved_trips").insert({
          user_id: user.id,
          trip_id: tripId,
        })
        setSavedTrips((prev) => [...prev, tripId])
      }
    } catch (error) {
      console.error("Error saving trip:", error)
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {mockTrips.map((trip) => (
        <Card key={trip.id} className="overflow-hidden hover:shadow-lg transition-shadow bg-card border-border">
          {/* Image */}
          <div className="relative h-48 bg-muted overflow-hidden">
            <img
              src={trip.image || "/placeholder.svg"}
              alt={trip.title}
              className="w-full h-full object-cover hover:scale-105 transition-transform"
            />
            <div className="absolute top-3 right-3 bg-black/60 px-3 py-1 rounded-full">
              <p className="text-white font-medium text-sm">{trip.price}</p>
            </div>
          </div>

          {/* Content */}
          <div className="p-4 space-y-3">
            <div>
              <h3 className="text-lg font-bold text-foreground line-clamp-2">{trip.title}</h3>
              <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                <MapPin size={16} />
                {trip.destination}
              </div>
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-2">
              {trip.tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>

            {/* Trip Info */}
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Calendar size={16} />
                {trip.dates}
              </div>
              <div className="flex items-center gap-2">
                <Users size={16} />
                {trip.travelers}/{trip.maxTravelers} travelers
              </div>
            </div>

            {/* Creator */}
            <div className="pt-2 border-t border-border">
              <p className="text-sm font-medium text-foreground">
                {trip.creator}
                <span className="text-primary ml-1">★ {trip.trustScore}%</span>
              </p>
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-4">
              <Button asChild className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground">
                <Link href={`/trip/${trip.id}`}>View Trip</Link>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => toggleSave(trip.id)}
                disabled={isLoading}
                className={`${savedTrips.includes(trip.id) ? "bg-primary/10 text-primary" : "hover:bg-muted"}`}
              >
                <Heart size={20} fill={savedTrips.includes(trip.id) ? "currentColor" : "none"} />
              </Button>
              <Button variant="ghost" size="icon" className="hover:bg-muted">
                <Share2 size={20} />
              </Button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
