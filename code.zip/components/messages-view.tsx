"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { createClient } from "@/lib/supabase/client"

interface Conversation {
  id: string
  name: string
  avatar: string
  lastMessage: string
  lastMessageTime: string
  unread: number
  isOnline: boolean
}

export function MessagesView() {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    const fetchConversations = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) return

        const { data: messages } = await supabase
          .from("messages")
          .select("*")
          .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
          .order("created_at", { ascending: false })

        // Group by conversation
        const convMap = new Map<string, Conversation>()
        messages?.forEach((msg: any) => {
          const otherId = msg.sender_id === user.id ? msg.receiver_id : msg.sender_id
          if (!convMap.has(otherId)) {
            supabase
              .from("users")
              .select("full_name")
              .eq("id", otherId)
              .single()
              .then(({ data: otherUser }) => {
                convMap.set(otherId, {
                  id: otherId,
                  name: otherUser?.full_name || "Unknown",
                  avatar: "/placeholder.svg",
                  lastMessage: msg.content,
                  lastMessageTime: new Date(msg.created_at).toLocaleDateString(),
                  unread: !msg.read && msg.receiver_id === user.id ? 1 : 0,
                  isOnline: false,
                })
              })
          }
        })

        setConversations(Array.from(convMap.values()))
      } catch (error) {
        console.error("Failed to fetch conversations:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchConversations()
  }, [supabase])

  const filteredConversations = conversations.filter((conv) =>
    conv.name.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const totalUnread = conversations.reduce((sum, conv) => sum + conv.unread, 0)

  if (isLoading) {
    return <div className="text-center py-12">Loading messages...</div>
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
      {/* Conversations List */}
      <Card className="bg-card border-border overflow-hidden flex flex-col lg:col-span-1">
        <div className="p-4 border-b border-border space-y-4">
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-foreground">Messages</h2>
            {totalUnread > 0 && <Badge className="bg-primary/20 text-primary">{totalUnread} unread</Badge>}
          </div>

          <div className="relative">
            <Search size={18} className="absolute left-3 top-3 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-background border-border"
            />
          </div>
        </div>

        <div className="overflow-y-auto flex-1">
          {filteredConversations.length > 0 ? (
            filteredConversations.map((conv) => (
              <Link
                key={conv.id}
                href={`/messages/${conv.name.toLowerCase().replace(/\s+/g, "-").replace(/\.$/, "")}`}
                className={`flex items-center gap-3 p-4 border-b border-border hover:bg-muted/50 transition cursor-pointer`}
              >
                <div className="relative">
                  <Avatar className="w-12 h-12">
                    <AvatarFallback>{conv.name[0]}</AvatarFallback>
                  </Avatar>
                  {conv.isOnline && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-primary rounded-full border-2 border-background"></div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-semibold text-foreground truncate">{conv.name}</h3>
                    {conv.unread > 0 && (
                      <Badge className="bg-primary text-primary-foreground text-xs">{conv.unread}</Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground truncate">{conv.lastMessage}</p>
                  <p className="text-xs text-muted-foreground mt-1">{conv.lastMessageTime}</p>
                </div>
              </Link>
            ))
          ) : (
            <div className="p-4 text-center text-muted-foreground">No conversations found</div>
          )}
        </div>
      </Card>

      {/* Empty State for Desktop */}
      <div className="hidden lg:flex lg:col-span-2 items-center justify-center rounded-lg bg-muted/30">
        <div className="text-center space-y-4">
          <div className="text-5xl">💬</div>
          <p className="text-muted-foreground">Select a conversation to start messaging</p>
        </div>
      </div>
    </div>
  )
}
